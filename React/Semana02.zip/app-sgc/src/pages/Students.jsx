import React from 'react';

function Students() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4">
      <h1 className="text-4xl font-bold">Students</h1>
      <p className="text-lg text-gray-600">Student management page.</p>
    </div>
  );
}

export default Students;